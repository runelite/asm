/*
 * Manage Java 5 annotations using ASM toolkit
 * Copyright (c) 2004, Eugene Kuleshov
 *
 * This library is free software; you can redistribute it and/or            
 * modify it under the terms of the GNU Lesser General Public               
 * License as published by the Free Software Foundation; either             
 * version 2.1 of the License, or (at your option) any later version.       
 *                                                                          
 * This library is distributed in the hope that it will be useful,          
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        
 * Lesser General Public License for more details.                          
 *                                                                          
 * You should have received a copy of the GNU Lesser General Public         
 * License along with this library; if not, write to the Free Software      
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package asm2;

import org.objectweb.asm.*;
import org.objectweb.asm.attrs.*;
import java.util.*;


public class Calculator1Dump implements Constants {

public static byte[] dump () throws Exception {

ClassWriter cw = new ClassWriter(false);
CodeVisitor cv;

cw.visit(V1_5, ACC_PUBLIC + ACC_SUPER, 
    "Calculator1", "java/lang/Object", null, 
    "Calculator1.java");

cw.visitField(ACC_PRIVATE, "result", "I", 
    null, null);

{
cv = cw.visitMethod(ACC_PUBLIC, "<init>", "()V", 
    null, null);
cv.visitVarInsn(ALOAD, 0);
cv.visitMethodInsn(INVOKESPECIAL, 
    "java/lang/Object", "<init>", "()V");
cv.visitInsn(RETURN);
cv.visitMaxs(1, 1);
}
{
cv = cw.visitMethod(ACC_PRIVATE, "sum", "(II)V", 
    null, null);
cv.visitVarInsn(ALOAD, 0);
cv.visitVarInsn(ILOAD, 1);
cv.visitVarInsn(ILOAD, 2);
cv.visitInsn(IADD);
cv.visitFieldInsn(PUTFIELD, "Calculator1", 
    "result", "I");
cv.visitInsn(RETURN);
cv.visitMaxs(3, 3);
}
cw.visitEnd();

return cw.toByteArray();
}
}
