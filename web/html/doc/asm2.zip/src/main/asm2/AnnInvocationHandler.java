/*
 * Manage Java 5 annotations using ASM toolkit
 * Copyright (c) 2004, Eugene Kuleshov
 *
 * This library is free software; you can redistribute it and/or            
 * modify it under the terms of the GNU Lesser General Public               
 * License as published by the Free Software Foundation; either             
 * version 2.1 of the License, or (at your option) any later version.       
 *                                                                          
 * This library is distributed in the hope that it will be useful,          
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        
 * Lesser General Public License for more details.                          
 *                                                                          
 * You should have received a copy of the GNU Lesser General Public         
 * License along with this library; if not, write to the Free Software      
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package asm2;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.List;


public class AnnInvocationHandler 
    implements InvocationHandler {
  private final String type;
  private final List values;

  public AnnInvocationHandler(String type, 
        List values) {
    this.type = type;
    this.values = values;
  }

  public Object invoke(Object proxy, Method m, 
        Object[] args) throws Throwable {
    String name = m.getName();

    if("toString".equals(name)) {
      StringBuffer sb = new StringBuffer(type);
      sb.append("[");
      String sep = "";
      for(int i = 0; i < values.size(); i++) {
        Object[] v = (Object[]) values.get(i);
        sb.append(sep).append(v[0]+"="+v[1]);
        sep = "; ";
      }
      sb.append("]");
      return sb.toString();
    }
    
    for(int i = 0; i < values.size(); i++) {
      Object[] value = (Object[]) values.get(i);
      if(value[ 0].equals(name)) {
        return value[ 1];
      }
    }
    
    String msg = "Invalid method call: "+name;
    throw new RuntimeException(msg);
  }

}

