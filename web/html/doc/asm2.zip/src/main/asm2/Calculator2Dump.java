/*
 * Manage Java 5 annotations using ASM toolkit
 * Copyright (c) 2004, Eugene Kuleshov
 *
 * This library is free software; you can redistribute it and/or            
 * modify it under the terms of the GNU Lesser General Public               
 * License as published by the Free Software Foundation; either             
 * version 2.1 of the License, or (at your option) any later version.       
 *                                                                          
 * This library is distributed in the hope that it will be useful,          
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        
 * Lesser General Public License for more details.                          
 *                                                                          
 * You should have received a copy of the GNU Lesser General Public         
 * License along with this library; if not, write to the Free Software      
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package asm2;

import org.objectweb.asm.*;
import org.objectweb.asm.attrs.*;
import java.util.*;


public class Calculator2Dump implements Constants {

public static byte[] dump () throws Exception {

ClassWriter cw = new ClassWriter(false);
CodeVisitor cv;

cw.visit(V1_5, ACC_PUBLIC + ACC_SUPER, 
    "Calculator2", "java/lang/Object", null, 
    "Calculator2.java");

// FIELD ATTRIBUTES
RuntimeInvisibleAnnotations fAtt1 = 
    new RuntimeInvisibleAnnotations();
Annotation fAtt1ann0 = new Annotation("LMarker;");
fAtt1ann0.add( "value", "Field");
fAtt1.annotations.add( fAtt1ann0);
cw.visitField(ACC_PRIVATE, "result", "I", 
    null, fAtt1);

{
cv = cw.visitMethod(ACC_PUBLIC, "<init>", "()V", 
    null, null);
cv.visitVarInsn(ALOAD, 0);
cv.visitMethodInsn(INVOKESPECIAL, 
    "java/lang/Object", "<init>", "()V");
cv.visitInsn(RETURN);
cv.visitMaxs(1, 1);
}
{
// METHOD ATTRIBUTES
RuntimeInvisibleParameterAnnotations mAtt1 = 
    new RuntimeInvisibleParameterAnnotations();
List mAtt1p0 = new ArrayList();
mAtt1.parameters.add( mAtt1p0);

List mAtt1p1 = new ArrayList();
Annotation mAtt1p1a0 = new Annotation("LMarker;");
mAtt1p1a0.add( "value", "Parameter");
mAtt1p1.add( mAtt1p1a0);

mAtt1.parameters.add( mAtt1p1);

RuntimeInvisibleAnnotations mAtt2 = 
    new RuntimeInvisibleAnnotations();
Annotation mAtt2a0 = new Annotation("LMarker;");
mAtt2a0.add( "value", "Method");
mAtt2.annotations.add( mAtt2a0);

mAtt1.next = mAtt2;

cv = cw.visitMethod(ACC_PRIVATE, "sum", "(II)V", 
    null, mAtt1);

cv.visitVarInsn(ALOAD, 0);
cv.visitVarInsn(ILOAD, 1);
cv.visitVarInsn(ILOAD, 2);
cv.visitInsn(IADD);
cv.visitFieldInsn(PUTFIELD, "Calculator2", 
    "result", "I");
cv.visitInsn(RETURN);
cv.visitMaxs(3, 3);
}
{
// CLASS ATRIBUTE
RuntimeInvisibleAnnotations attr = 
    new RuntimeInvisibleAnnotations();
Annotation attrann0 = new Annotation("LMarker;");
attrann0.add( "value", "Class");
attr.annotations.add( attrann0);
cw.visitAttribute(attr);
}
cw.visitEnd();

return cw.toByteArray();
}
}
