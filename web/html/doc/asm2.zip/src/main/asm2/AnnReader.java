/*
 * Manage Java 5 annotations using ASM toolkit
 * Copyright (c) 2004, Eugene Kuleshov
 *
 * This library is free software; you can redistribute it and/or            
 * modify it under the terms of the GNU Lesser General Public               
 * License as published by the Free Software Foundation; either             
 * version 2.1 of the License, or (at your option) any later version.       
 *                                                                          
 * This library is distributed in the hope that it will be useful,          
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        
 * Lesser General Public License for more details.                          
 *                                                                          
 * You should have received a copy of the GNU Lesser General Public         
 * License along with this library; if not, write to the Free Software      
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package asm2;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.objectweb.asm.Attribute;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.CodeVisitor;
import org.objectweb.asm.Type;
import org.objectweb.asm.attrs.Annotation;
import org.objectweb.asm.attrs.Annotation.EnumConstValue;
import org.objectweb.asm.attrs.Attributes;
import org.objectweb.asm.attrs.RuntimeInvisibleAnnotations;
import org.objectweb.asm.attrs.RuntimeInvisibleParameterAnnotations;
import org.objectweb.asm.attrs.RuntimeVisibleAnnotations;
import org.objectweb.asm.attrs.RuntimeVisibleParameterAnnotations;


public class AnnReader implements ClassVisitor {
  private List classAnns = new ArrayList();
  private Map fieldAnns = new HashMap();
  private Map methodAnns = new HashMap();
  private Map methodParamAnns = new HashMap();


  public AnnReader(InputStream is) 
      throws IOException {
    ClassReader r = new ClassReader(is);
    r.accept(this, 
        Attributes.getDefaultAttributes(), true);
  }

  public List getClassAnnotations() {
    return classAnns;
  }
  
  public Map getFieldAnnotations() {
    return fieldAnns;
  }
  
  public Map getMethodAnnotations() {
    return methodAnns;
  }
  
  public Map getMethodParamAnnotations() {
    return methodParamAnns;
  }
  
  
  public void visitAttribute(Attribute attr) {
    classAnns.addAll(loadAnns(attr));
  }
  
  public void visitField(int access, 
        String name, String desc, Object value, 
        Attribute attrs) {
    fieldAnns.put(name+desc, loadAnns(attrs));
  }
  
  public CodeVisitor visitMethod(int access, 
        String name, String desc, 
        String[] exceptions, Attribute attrs) {
    methodAnns.put(name+desc, loadAnns(attrs));
    methodParamAnns.put(name+desc, 
        loadParamAnns(attrs));
    return null;
  }
  
  public void visit( int version, int access, 
      String name, String superName, 
      String[] interfaces, String sourceFile) {
  }

  public void visitInnerClass( String name,
      String outer, String inner, int access) {
  }
  
  public void visitEnd() {
  }
  
  
  // Annotation loading
  
  private List loadAnns(Attribute a) {
    List anns = new ArrayList();
    while(a!=null) {
      if(a instanceof 
          RuntimeVisibleAnnotations) {
        RuntimeVisibleAnnotations ra = 
            (RuntimeVisibleAnnotations) a;
        addAnns(anns, ra.annotations);
      } else if(a instanceof 
          RuntimeInvisibleAnnotations) {
        RuntimeInvisibleAnnotations ra = 
            (RuntimeInvisibleAnnotations) a;
        addAnns(anns, ra.annotations);
      }
      a = a.next;
    }
    return anns;
  }

  private List loadParamAnns(Attribute a) {
    List anns = new ArrayList();
    while(a!=null) {
      if(a instanceof 
          RuntimeVisibleParameterAnnotations) {
        RuntimeVisibleParameterAnnotations ra = 
          (RuntimeVisibleParameterAnnotations) a;
        addParamAnns( anns, ra.parameters);
      } else if(a instanceof 
          RuntimeInvisibleParameterAnnotations) {
        RuntimeInvisibleParameterAnnotations ra = 
          (RuntimeInvisibleParameterAnnotations) a;
        addParamAnns( anns, ra.parameters);
      }
      a = a.next;
    }
    return anns;
  }

  private void addParamAnns( List anns, List params) {
    for(Iterator it = params.iterator(); it.hasNext();) {
      List paramAttrs = (List) it.next();
      List paramAnns = new ArrayList();
      addAnns(paramAnns, paramAttrs);
      anns.add(paramAnns);
    }
  }

  private void addAnns(List anns, List attr) {
    for(int i = 0; i<attr.size(); i++) {
      anns.add(loadAnn((Annotation) attr.get(i)));
    }
  }

  private Object loadAnn(Annotation annotation) {
    String type = annotation.type;
    List vals = annotation.elementValues;
    List nvals = new ArrayList(vals.size());
    for(int i = 0; i < vals.size(); i++) {
      Object[] element = (Object[]) vals.get(i);
      String name = (String) element[0];
      Object value = getValue(element[1]);
      nvals.add(new Object[] { name, value});
    }
    
    try {
      Type t = Type.getType(type);
      String cname = t.getClassName();
      Class typeClass = Class.forName(cname);
      ClassLoader cl = getClass().getClassLoader();
      return Proxy.newProxyInstance(cl, 
          new Class[] { Ann.class, typeClass}, 
          new AnnInvocationHandler(type, nvals));
    
    } catch(ClassNotFoundException ex) {
      throw new RuntimeException(ex.toString());
    
    }
  }

  private Object getValue(Object value) {
    if (value instanceof EnumConstValue) {
      // TODO convert to java.lang.Enum adapter
      return value;
    }
    if (value instanceof Type) {
      String cname = ((Type)value).getClassName();
      try {
        // TODO may require additional filtering
        return Class.forName(cname);
      } catch(ClassNotFoundException e) {
        throw new RuntimeException(e.toString());
      }
    }
    if (value instanceof Annotation) {
      return loadAnn(((Annotation) value));
    }
    if (value instanceof Object[]) {
      Object[] values = (Object[]) value;
      Object[] o = new Object[ values.length];
      for(int i = 0; i < values.length; i++) {
        o[ i] = getValue(values[ i]);
      }
      return o;
    }

    return value;
  }
  
}

