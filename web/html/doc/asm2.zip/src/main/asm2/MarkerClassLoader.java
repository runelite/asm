/*
 * Manage Java 5 annotations using ASM toolkit
 * Copyright (c) 2004, Eugene Kuleshov
 *
 * This library is free software; you can redistribute it and/or            
 * modify it under the terms of the GNU Lesser General Public               
 * License as published by the Free Software Foundation; either             
 * version 2.1 of the License, or (at your option) any later version.       
 *                                                                          
 * This library is distributed in the hope that it will be useful,          
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        
 * Lesser General Public License for more details.                          
 *                                                                          
 * You should have received a copy of the GNU Lesser General Public         
 * License along with this library; if not, write to the Free Software      
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package asm2;

import java.io.PrintWriter;
import java.net.URL;

import org.objectweb.asm.ClassAdapter;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Constants;
import org.objectweb.asm.Type;
import org.objectweb.asm.attrs.Annotation;
import org.objectweb.asm.attrs.Attributes;
import org.objectweb.asm.attrs.RuntimeVisibleAnnotations;
import org.objectweb.asm.util.TraceClassVisitor;


public class MarkerClassLoader 
    extends ClassLoader {

  private Class c;

  public MarkerClassLoader( Class c) {
    this.c = c;
  }
  
  public Class loadClass( String name) 
        throws ClassNotFoundException {
    String resourceName = 
        "/"+name.replace( '.', '/')+".class";
    URL url = c.getResource( resourceName);
    if( name.startsWith( "java") || 
        name.equals(Marker.class.getName()) || 
        url==null) {
      return c.getClassLoader().loadClass( name);
    }

    ClassWriter cw = new ClassWriter(false);
    try {
      ClassReader cr = 
        new ClassReader(url.openStream());
      cr.accept(new MarkerClassVisitor(cw), 
        Attributes.getDefaultAttributes(), false);
      
      byte[] b = cw.toByteArray();
      return defineClass( name, b, 0, b.length);
      
    } catch( Exception ex) {
      throw new ClassNotFoundException(
          "Unable to load class "+name);
    
    }
  }
  
  
  public static class MarkerClassVisitor extends ClassAdapter {

    public MarkerClassVisitor(ClassVisitor cv) {
      super(cv);
    }
    
    public void visit( int version, int access, 
        String name, String superName, 
        String[] interfaces, String sourceFile) {
      super.visit( Constants.V1_5, access, name, 
          superName, interfaces, sourceFile);
    }
    
    public void visitEnd() {
      String t = Type.getDescriptor(Marker.class);
      Annotation ann = new Annotation(t);
      ann.add("value", "Class");

      RuntimeVisibleAnnotations attr = 
        new RuntimeVisibleAnnotations();
      attr.annotations.add(ann);      
      cv.visitAttribute(attr);
      
      super.visitEnd();
    }

  }
  
}

