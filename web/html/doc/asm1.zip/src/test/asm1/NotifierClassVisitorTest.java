/*
 * Java bytecode manipulation with ASM toolkit
 * Copyright (c) 2004, Eugene Kuleshov
 *
 * This library is free software; you can redistribute it and/or            
 * modify it under the terms of the GNU Lesser General Public               
 * License as published by the Free Software Foundation; either             
 * version 2.1 of the License, or (at your option) any later version.       
 *                                                                          
 * This library is distributed in the hope that it will be useful,          
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        
 * Lesser General Public License for more details.                          
 *                                                                          
 * You should have received a copy of the GNU Lesser General Public         
 * License along with this library; if not, write to the Free Software      
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package asm1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;


public class NotifierClassVisitorTest extends TestCase {
  private static final String TEST_CLASS = "asm1.Counter1";
  
  private TestListener listener;
  private Counter counter;


  public void setUp() throws Exception {
    super.setUp();
    
    listener = new TestListener();
    
    Class cc = loadClass(TEST_CLASS);
    counter = ( Counter) cc.newInstance();
    
    (( Notifier) counter).addListener( listener);
  }
  
  
  public void testCounter() {
    int n1 = counter.count();
    counter.increment();
    int n2 = counter.count();
    assertEquals( n1+1, n2);
  }

  public void testNotifier() {
    counter.count();
    counter.increment();
    counter.count();

    List events = listener.getEvents();
    assertEquals( 3, events.size());
  }

  
  private Class loadClass(final String className) throws ClassNotFoundException {
    ClassLoader cl = new TestClassLoader(getClass().getClassLoader(), className);
    return cl.loadClass(className);
  }

  
  private static final class TestClassLoader extends ClassLoader {
    private final String className;
    private final ClassLoader cl;

    public TestClassLoader(ClassLoader cl, String className) {
      super();
      this.cl = cl;
      this.className = className;
    }

    public Class loadClass(String name) throws ClassNotFoundException {
      if( className.equals(name)) {
        try {
          byte[] bytecode = transformClass( className);
          return super.defineClass( className, bytecode, 0, bytecode.length);            
        
        } catch( IOException ex) {
          throw new ClassNotFoundException( "Load error: "+ex.toString(), ex);
        
        }        
      }
      return cl.loadClass( name);
    }
    
    private byte[] transformClass( String className) throws IOException {
      ClassWriter cw = new ClassWriter( true, true);
      NotifierClassVisitor ncv = new NotifierClassVisitor( cw);
   
      ClassReader cr = new ClassReader( getClass().getResourceAsStream( "/"+className.replace('.','/')+".class"));
      cr.accept( ncv, false);
      return cw.toByteArray();
    }
    
  }


  private static final class TestListener implements Listener {
    private List events = new ArrayList();

    public void notify( Object src, Object msg) {
      events.add( new Object[] { src, msg});
    }

    public List getEvents() {
      return events;
    }
    
  }
  
}

