/*
 * Java bytecode manipulation with ASM toolkit
 * Copyright (c) 2004, Eugene Kuleshov
 *
 * This library is free software; you can redistribute it and/or            
 * modify it under the terms of the GNU Lesser General Public               
 * License as published by the Free Software Foundation; either             
 * version 2.1 of the License, or (at your option) any later version.       
 *                                                                          
 * This library is distributed in the hope that it will be useful,          
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        
 * Lesser General Public License for more details.                          
 *                                                                          
 * You should have received a copy of the GNU Lesser General Public         
 * License along with this library; if not, write to the Free Software      
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package asm1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.objectweb.asm.Attribute;
import org.objectweb.asm.ClassAdapter;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.CodeVisitor;
import org.objectweb.asm.Constants;
import org.objectweb.asm.Label;
import org.objectweb.asm.Type;


public class NotifierClassVisitor extends ClassAdapter implements Constants {
  private static final String NOTIFIER = Type.getType(Notifier.class).getInternalName();
  private static final String LISTENER = Type.getType(Listener.class).getInternalName();

  private String className;

  public NotifierClassVisitor( ClassVisitor cv) {
    super( cv);
  }

  public void visit( int version, int access, 
      String name, String superName,
      String[] interfaces, String sourceFile) {
    this.className = name;
    List c = interfaces==null ? 
        new ArrayList() : new ArrayList( Arrays.asList( interfaces));
    c.add( NOTIFIER); 
    cv.visit( version, access, name, superName,
        (String[])c.toArray(new String[c.size()]),
        sourceFile);
  }
  
  public void visitEnd() {
    // adding new field
    cv.visitField(ACC_PRIVATE, "__lst", 
        "Ljava/util/ArrayList;", null, null);

    // adding new methods
    CodeVisitor cd;
    {
    cd = cv.visitMethod(ACC_PUBLIC, "notify", 
        "(Ljava/lang/String;)V", null, null);
    cd.visitInsn(ICONST_0);
    cd.visitVarInsn(ISTORE, 2);
    Label l0 = new Label();
    cd.visitLabel(l0);
    cd.visitVarInsn(ILOAD, 2);
    cd.visitVarInsn(ALOAD, 0);
    cd.visitFieldInsn(GETFIELD, className, 
        "__lst", "Ljava/util/ArrayList;");
    cd.visitMethodInsn(INVOKEVIRTUAL, 
        "java/util/ArrayList", "size", "()I");
    Label l1 = new Label();
    cd.visitJumpInsn(IF_ICMPGE, l1);
    cd.visitVarInsn(ALOAD, 0);
    cd.visitFieldInsn(GETFIELD, className, 
        "__lst", "Ljava/util/ArrayList;");
    cd.visitVarInsn(ILOAD, 2);
    cd.visitMethodInsn(INVOKEVIRTUAL, 
        "java/util/ArrayList", "get", 
        "(I)Ljava/lang/Object;");
    cd.visitTypeInsn(CHECKCAST, LISTENER);
    cd.visitVarInsn(ALOAD, 0);
    cd.visitVarInsn(ALOAD, 1);
    cd.visitMethodInsn(INVOKEINTERFACE,
        LISTENER, "notify", 
        "(Ljava/lang/Object;Ljava/lang/Object;)V");
    cd.visitIincInsn(2, 1);
    cd.visitJumpInsn(GOTO, l0);
    cd.visitLabel(l1);
    cd.visitInsn(RETURN);
    cd.visitMaxs(1, 1);
    }
    {
    cd = cv.visitMethod(ACC_PUBLIC, "addListener",
       "(Lasm1/Listener;)V", null, null);
    cd.visitVarInsn(ALOAD, 0);
    cd.visitFieldInsn(GETFIELD, className,
        "__lst", "Ljava/util/ArrayList;");
    cd.visitVarInsn(ALOAD, 1);
    cd.visitMethodInsn(INVOKEVIRTUAL, 
       "java/util/ArrayList", "add", 
       "(Ljava/lang/Object;)Z");
    cd.visitInsn(POP);
    cd.visitInsn(RETURN);
    cd.visitMaxs(1, 1);
    }

    cv.visitEnd();
  } 
  
  public CodeVisitor visitMethod( int access,
      String name, String desc, 
      String[] exceptions, Attribute attrs) {
    CodeVisitor cd = cv.visitMethod( access, 
        name, desc, exceptions, attrs);
    if( cd==null) return null;

    if( "<init>".equals( name)) {
      return new NotifierCodeAdapter( cd, className);
    }
    if((access & Constants.ACC_STATIC)==0) {
      // add instructions to call notify() method
      cd.visitVarInsn(ALOAD, 0);
      cd.visitLdcInsn(name+desc);
      cd.visitMethodInsn(INVOKEVIRTUAL, className,
          "notify", "(Ljava/lang/String;)V");
    }
    return cd;
  }
  
}

